"""Legendary!"""

__version__ = '0.20.34'
__codename__ = 'Direct Intervention'
