# coding: utf-8

class InvalidCredentialsError(Exception):
    pass
