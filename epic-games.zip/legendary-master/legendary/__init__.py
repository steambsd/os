"""Legendary!"""

__version__ = '0.20.10'
__codename__ = 'Black Mesa East'
