"""Legendary!"""

__version__ = '0.20.26'
__codename__ = 'Dark Energy'
