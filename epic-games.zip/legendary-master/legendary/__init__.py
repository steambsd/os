"""Legendary!"""

__version__ = '0.20.6'
__codename__ = 'A Red Letter Day'
