"""Legendary!"""

__version__ = '0.20.18'
__codename__ = 'Entanglement (hotfix)'
