"""Legendary!"""

__version__ = '0.20.28'
__codename__ = 'Dark Energy (hotfix #2)'
