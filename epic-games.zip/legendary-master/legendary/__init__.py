"""Legendary!"""

__version__ = '0.20.31'
__codename__ = 'Dark Energy (hotfix #5)'
