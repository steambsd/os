"""Legendary!"""

__version__ = '0.20.22'
__codename__ = 'Anticitizen One (hotfix #3)'
