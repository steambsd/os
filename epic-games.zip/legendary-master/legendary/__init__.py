"""Legendary!"""

__version__ = '0.20.27'
__codename__ = 'Dark Energy (hotfix)'
