"""Legendary!"""

__version__ = '0.20.33'
__codename__ = 'Undue Alarm'
