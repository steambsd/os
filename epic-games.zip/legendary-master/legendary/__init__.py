"""Legendary!"""

__version__ = '0.20.16'
__codename__ = 'Nova Prospekt (hotfix #2)'
