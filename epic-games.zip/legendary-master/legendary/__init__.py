"""Legendary!"""

__version__ = '0.20.25'
__codename__ = 'Our Benefactors'
