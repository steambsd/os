"""Legendary!"""

__version__ = '0.20.12'
__codename__ = 'Highway 17'
