#!/bin/sh
__dir__="$(dirname "$(realpath "$0")")"
exec lsu-linux-to-freebsd-env "$__dir__/run.rb" "$@"
